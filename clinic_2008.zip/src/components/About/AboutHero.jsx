import React from 'react';
import styles from './AboutHero.module.css';

const AboutHero = () => {
  return (
    <section className={styles.heroSection}>
      <h1>About</h1>
      {/* <p>Discover our story</p> */}
    </section>
  );
};

export default AboutHero;
